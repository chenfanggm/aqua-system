using UnityEngine;

namespace com.aqua.grid
{
    public enum GridState
    {
        Initializing,
        Idle,
        Updating
    }
}
