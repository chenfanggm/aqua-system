namespace com.aqua.grid
{
    public enum GridCorner
    {
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }
}
