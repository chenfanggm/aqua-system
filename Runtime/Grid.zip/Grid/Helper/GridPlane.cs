namespace com.aqua.grid
{
    public enum GridPlane
    {
        XY = 0,
        XZ = 1
    }

}