namespace com.aqua.grid
{
    public enum GridOperation
    {
        Initialize,
        Insert,
        Move,
        Remove,
        Swap,
        Clear,
        Resize,
    }
}
