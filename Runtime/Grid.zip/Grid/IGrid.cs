using System;
using System.Collections.Generic;
using UnityEngine;

namespace com.aqua.grid
{
    /// <summary>
    /// Core interface for grid operations
    /// Provides essential grid functionality while allowing different implementations
    /// </summary>
    public interface IGrid<T>
        where T : Tile, new()
    {
        #region Properties

        /// <summary>
        /// Indicates if the grid is currently in an updating state
        /// </summary>
        GridState State { get; }

        /// <summary>
        /// Size of the grid (width x height)
        /// </summary>
        Vector2Int GridSize { get; }

        /// <summary>
        /// Size of each cell in world units
        /// </summary>
        float CellSize { get; }

        /// <summary>
        /// Spacing between cells
        /// </summary>
        float CellSpacing { get; }

        /// <summary>
        /// Origin point of the grid in world space
        /// </summary>
        Vector3 Origin { get; }

        /// <summary>
        /// Event fired when the grid is initialized
        /// </summary>
        event EventHandler<GridInitializedEventArgs<T>> OnInitialized;

        /// <summary>
        /// Event fired when the grid is updated
        /// </summary>
        event EventHandler<GridUpdatedEventArgs<T>> OnUpdated;

        /// <summary>
        /// Event fired when the grid is cleared
        /// </summary>
        event EventHandler<IReadOnlyList<T>> OnCleared;

        #endregion

        #region Write Operations

        /// <summary>
        /// Initialize the grid
        /// </summary>
        void Initialize();

        /// <summary>
        /// Reconfigure the grid
        /// </summary>
        void Reconfigure(Vector2Int gridSize, float cellSize, float cellSpacing);

        /// <summary>
        /// Clear the grid
        /// </summary>
        List<T> Clear();

        /// <summary>
        /// Set multiple tiles at their respective grid positions in a single batch operation.
        /// This method emits only one update event at the end instead of one per tile.
        /// </summary>
        void SetTiles(List<(T tile, Vector2Int gridPos)> tilesWithPositions);

        /// <summary>
        /// Remove tiles from the grid.
        /// </summary>
        void RemoveTiles(List<T> tiles);

        /// <summary>
        /// Swap two tiles in the grid and return their movements
        /// </summary>
        List<TileMovement<T>> SwapTiles(T tile1, T tile2);
        #endregion

        #region Read Operations
        /// <summary>
        /// Get all tiles in the grid (excluding empty cells)
        /// </summary>
        List<T> GetAllTiles();

        /// <summary>
        /// Get all tiles in a specific column from bottom to top
        /// </summary>
        List<T> GetColumnTiles(int columnIndex);

        /// <summary>
        /// Get all tiles in a specific row from left to right
        /// </summary>
        List<T> GetRowTiles(int rowIndex);

        /// <summary>
        /// Get the cell at the specified position
        /// </summary>
        Cell<T> GetCellAt(Vector2Int gridPos);

        /// <summary>
        /// Get the tile at the specified position
        /// </summary>
        T GetTileAt(Vector2Int gridPos);

        /// <summary>
        /// Check if a position has a tile
        /// </summary>
        bool HasTile(Vector2Int gridPos);
        #endregion

        #region Basic Grid
        /// <summary>
        /// Convert world position to grid position
        /// </summary>
        Vector2Int GetGridPosition(Vector3 worldPosition);

        /// <summary>
        /// Get the world position of a cell
        /// </summary>
        Vector3 GetWorldPosition(Vector2Int gridPosition);

        /// <summary>
        /// Get the center world position of a cell
        /// </summary>
        Vector3 GetCenterWorldPosition(Vector2Int gridPosition);

        /// <summary>
        /// Check if grid position is within bounds
        /// </summary>
        bool IsValidPosition(Vector2Int position);

        /// <summary>
        /// Check if two positions are adjacent
        /// </summary>
        bool AreAdjacent(Vector2Int pos1, Vector2Int pos2);

        /// <summary>
        /// Check if two positions are diagonal
        /// </summary>
        bool AreDiagonal(Vector2Int pos1, Vector2Int pos2);

        #endregion

        #region Cloning

        /// <summary>
        /// Create a deep clone of this grid for simulation purposes
        /// </summary>
        IGrid<T> Clone();

        #endregion
    }
}
